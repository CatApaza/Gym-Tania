const express = require('express');
const EntrenadorService = require('../services/entrenadorService');
const ClienteService = require('../services/clienteService');

exports.obtenerEntrenador = async (req, res) => {
  try {
      const entrenador = await EntrenadorService.obtenerEntrenadorPorUsuario(req.user.id);
      if (!entrenador) {
        return res.status(404).json({ error:'Entrenador no encontrado' })
      }
      res.json(entrenador);
  } catch (error) {
      console.error('Error al obtener los datos del entrenador:', error.message);
      res.status(500).json({ error: 'Error del servidor' });
  }
}


exports.actualizarEntrenador = async (req, res) => {
  try {
      const usuarioId = req.user.id;
      const datosActualizados = req.body;

      const entrenadorActualizado = await EntrenadorService.actualizarEntrenador(usuarioId, datosActualizados);
      
      if(!entrenadorActualizado){
        return res.status(404).json({ error:'Entrenador no encontrado' });
      }

      res.json({ mensaje: 'Datos del entrenador actualizados correctamente'})

  } catch (error) {
      console.error('Error al actualizar los datos del entrenador:', error.message);
      res.status(500).json({ error: 'Error del servidor' });
  }
};

// Obtener los clientes asociados a un entrenador
exports.obtenerClientesDelEntrenador = async (req, res) => {
  try {
      // Obtener el ID del entrenador desde la sesión o parámetros
      const entrenadorId = req.params.entrenadorId || (req.session && req.session.usuario && req.session.usuario._id);
      
      if (!entrenadorId) {
          return res.status(400).json({ error: 'ID de entrenador no proporcionado' });
      }
      
      console.log(`Obteniendo clientes para el entrenador ${entrenadorId}`);
      
      // Obtener los clientes asignados al entrenador
      const clientes = await ClienteService.obtenerClientesPorEntrenador(entrenadorId);
      
      res.json(clientes);
  } catch (error) {
      console.error('Error al obtener clientes del entrenador:', error.message);
      res.status(500).json({ error: 'Error del servidor' });
  }
};