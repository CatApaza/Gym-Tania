module.exports={
    db:{
        host: 'localhost',
        user: '',
        password: '',
        database: 'gimnasioApp',
        port:27017
    }
}

/* PORT = 3000
MONGODB_URI = mongodb://127.0.0.1:27017/gimnasioApp */