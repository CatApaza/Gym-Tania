const express = require('express');
const router = express.Router();
const entrenadorController = require('../controllers/entrenadorController');

// Rutas básicas para entrenadores
router.get('/ver', entrenadorController.obtenerEntrenador);
router.put('/actualizar', entrenadorController.actualizarEntrenador);

// Ruta para obtener los clientes asociados a un entrenador
router.get('/clientes', entrenadorController.obtenerClientesDelEntrenador);
router.get('/clientes/:entrenadorId', entrenadorController.obtenerClientesDelEntrenador);

module.exports = router;